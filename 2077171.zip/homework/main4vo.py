'''
It is a main function that can be used for you to conduct the tasks in Visual Odometry.
You run this main function to generate the expected outputs and results described in the Instruction.pdf, 
by calling functions implemented in submission.py and helper.py
You are free to write it in your own style.
'''

# Insert your package here

if __name__ == "__main__":
	'''
	Replace pass with your implementation
	'''
	pass
